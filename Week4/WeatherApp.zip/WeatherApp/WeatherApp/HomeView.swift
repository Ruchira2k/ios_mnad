//
//  HomeView.swift
//  WeatherApp
//
//  Created by Ruchira Sahabandu  on 2023-02-17.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack(spacing: 20){
            Text("Colombo").font(.title).fontWeight(.light)
            
            Text("\(Date().formatted())")
            
            Text("25.99ºC").font(.system(size: 55)).bold()
            
            Text("Broken Clouds").font(.title).bold()
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
