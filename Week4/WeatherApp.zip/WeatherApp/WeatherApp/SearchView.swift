//
//  SearchView.swift
//  WeatherApp
//
//  Created by Ruchira Sahabandu  on 2023-02-17.
//

import SwiftUI

struct SearchView: View {
    @State var cityName: String = ""
    
    var body: some View {
        ScrollView{
            VStack(alignment: .leading){
                Text("Weather")
                    .font(.largeTitle)
                    .bold()
                HStack{
                    TextField("City Name", text:$cityName)
                        .textFieldStyle(.roundedBorder)
                    
                    Button {
                        
                    } label: {
                        Text("Search")
                    }
                }
                // Could use a LazyVGrid instead
                HStack{
                    WeatherConditionView(image: "aqi.low", title:"Broken Clouds", subtitle: "Current Status")
                    
                    WeatherConditionView(image: "thermometer.low", title:"26.5", subtitle: "Temperature (ºC)")
                }
                
                HStack{
                    WeatherConditionView(image: "humidity", title:"64.0", subtitle: "Humidity (%)")
                    
                    WeatherConditionView(image: "tornado", title:"1013.0", subtitle: "Pressure (Mbar)")
                }
                
                HStack{
                    WeatherConditionView(image: "sun.dust", title:"10000.0", subtitle: "Visibility")
                    
                    WeatherConditionView(image: "wind", title:"3.01", subtitle: "Wind Speed (km/h)")
                }
                WeatherConditionView(image: "cloud.fill", title:"68.0", subtitle: "Clouds(%)")
            }.padding()
        }
        
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}

// This is reusable
struct WeatherConditionView: View {
    var image: String = ""
    var title: String = ""
    var subtitle: String = ""
    
    
    
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 20)
                .frame(width: UIScreen.main.bounds.width * 0.45, height: 200)
                .foregroundColor(.gray).opacity(0.4)
            
            VStack(spacing: 15){
                Image(systemName: image).font(.system(size: 50))
                
                Text(title)
                    .font(.system(size: 20)).bold()
                
                Text(subtitle)
            }
        }
    }
}
