//
//  QuadraticSolverApp.swift
//  QuadraticSolver
//
//  Created by Ruchira Sahabandu  on 2023-02-24.
//

import SwiftUI

@main
struct QuadraticSolverApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
